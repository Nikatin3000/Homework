first_name = 'Vadim'
last_name = 'Kriuk'
print('Hello'+ ' ' + first_name + ' ' + last_name + ', nice to meet you')





