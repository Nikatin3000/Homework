a = int(input("Введіть перше число: "))
b = int(input("Введіть друге число: "))
print('a + b =', a + b )
print('a - b =', a - b )
print('a * b =', a * b )
print('a / b =', a / b )
print('a // b =', a // b )
print('a ** b =', a ** b )
print('a % b =', a % b )





