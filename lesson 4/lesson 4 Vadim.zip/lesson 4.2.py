number = input('Введіть номер телефону: ')

if len(number) == 10 and number.isdigit():
    print('Номер правильний')
else:
    print('Номер не правильний')



