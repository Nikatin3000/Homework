math_task = 2+(3*4)
user_answer = int(input("Дайте правильну відповідь на вираз - 2+(3*4): "))

if math_task == user_answer:
    print('Дякую, відповідь правильна)')
else:
    print('Вибачте, відповідь не правильна(')