name = input('Your name: ')
age = int(input('Your age: '))

print(f"Hello {name} , on your next birthday you’ll be {age + 1} years")

